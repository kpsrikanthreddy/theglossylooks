-- ==============================================================================
-- The Glossy Looks Database: Central SMAV Auth Linkage Migration
-- Target Database: https://onswigwiwuvkvoduuhxr.supabase.co (The Glossy Looks)
--
-- Instructions:
-- Run this SQL in the SQL Editor of The Glossy Looks Supabase project.
-- This migration PRESERVES all existing tables, services, categories, staff,
-- appointments, and branch data. It only adds central auth federation metadata.
-- ==============================================================================

BEGIN;

-- 1. Ensure staff/users table in Glossy Looks has central auth linkage columns
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'staff') THEN
    ALTER TABLE public.staff
      ADD COLUMN IF NOT EXISTS central_auth_id UUID,
      ADD COLUMN IF NOT EXISTS username TEXT,
      ADD COLUMN IF NOT EXISTS central_auth_status TEXT NOT NULL DEFAULT 'ACTIVE',
      ADD COLUMN IF NOT EXISTS central_auth_linked_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS central_outlet_code TEXT DEFAULT 'glossylooks',
      ADD COLUMN IF NOT EXISTS central_sync_version BIGINT NOT NULL DEFAULT 1,
      ADD COLUMN IF NOT EXISTS central_last_synced_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS central_sync_origin TEXT DEFAULT 'outlet_admin';

    CREATE INDEX IF NOT EXISTS idx_staff_central_auth_id ON public.staff(central_auth_id);
    CREATE INDEX IF NOT EXISTS idx_staff_central_auth_status ON public.staff(central_auth_status);
  END IF;

  IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users') THEN
    ALTER TABLE public.users
      ADD COLUMN IF NOT EXISTS central_auth_id UUID,
      ADD COLUMN IF NOT EXISTS username TEXT,
      ADD COLUMN IF NOT EXISTS central_auth_status TEXT NOT NULL DEFAULT 'ACTIVE',
      ADD COLUMN IF NOT EXISTS central_auth_linked_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS central_outlet_code TEXT DEFAULT 'glossylooks',
      ADD COLUMN IF NOT EXISTS central_sync_version BIGINT NOT NULL DEFAULT 1,
      ADD COLUMN IF NOT EXISTS central_last_synced_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS central_sync_origin TEXT DEFAULT 'outlet_admin';

    CREATE INDEX IF NOT EXISTS idx_users_central_auth_id ON public.users(central_auth_id);
  END IF;
END $$;

-- 2. Dynamically create status view matching whichever table exists in this database
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'staff') THEN
    EXECUTE 'CREATE OR REPLACE VIEW public.vw_smav_staff_auth_status AS
      SELECT 
        s.id AS local_staff_id,
        s.name,
        s.username,
        s.email,
        s.role,
        s.branch_id,
        COALESCE(s.is_active, true) AS is_active,
        s.central_auth_id,
        s.central_auth_status,
        s.central_auth_linked_at,
        s.central_sync_version,
        s.central_last_synced_at,
        CASE 
          WHEN s.central_auth_id IS NOT NULL AND COALESCE(s.is_active, true) = true THEN ''SYNCED_READY''
          WHEN s.central_auth_id IS NOT NULL THEN ''DISABLED''
          ELSE ''NEEDS_CENTRAL_SYNC''
        END AS smav_access_status
      FROM public.staff s;';

  ELSIF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users') THEN
    EXECUTE 'CREATE OR REPLACE VIEW public.vw_smav_staff_auth_status AS
      SELECT 
        u.id AS local_staff_id,
        COALESCE(u.full_name, u.email) AS name,
        u.username,
        u.email,
        u.role,
        NULL::text AS branch_id,
        COALESCE(u.is_active, true) AS is_active,
        u.central_auth_id,
        u.central_auth_status,
        u.central_auth_linked_at,
        u.central_sync_version,
        u.central_last_synced_at,
        CASE 
          WHEN u.central_auth_id IS NOT NULL AND COALESCE(u.is_active, true) = true THEN ''SYNCED_READY''
          WHEN u.central_auth_id IS NOT NULL THEN ''DISABLED''
          ELSE ''NEEDS_CENTRAL_SYNC''
        END AS smav_access_status
      FROM public.users u;';

  ELSE
    CREATE TABLE IF NOT EXISTS public.smav_staff_links (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email TEXT NOT NULL UNIQUE,
      username TEXT,
      name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'staff',
      is_active BOOLEAN NOT NULL DEFAULT true,
      central_auth_id UUID,
      central_auth_status TEXT NOT NULL DEFAULT 'ACTIVE',
      central_auth_linked_at TIMESTAMPTZ,
      central_sync_version BIGINT NOT NULL DEFAULT 1,
      central_last_synced_at TIMESTAMPTZ,
      central_sync_origin TEXT DEFAULT 'outlet_admin',
      created_at TIMESTAMPTZ DEFAULT now()
    );

    EXECUTE 'CREATE OR REPLACE VIEW public.vw_smav_staff_auth_status AS
      SELECT 
        l.id AS local_staff_id,
        l.name,
        l.username,
        l.email,
        l.role,
        NULL::text AS branch_id,
        l.is_active,
        l.central_auth_id,
        l.central_auth_status,
        l.central_auth_linked_at,
        l.central_sync_version,
        l.central_last_synced_at,
        CASE 
          WHEN l.central_auth_id IS NOT NULL AND l.is_active = true THEN ''SYNCED_READY''
          WHEN l.central_auth_id IS NOT NULL THEN ''DISABLED''
          ELSE ''NEEDS_CENTRAL_SYNC''
        END AS smav_access_status
      FROM public.smav_staff_links l;';
  END IF;
END $$;

COMMENT ON VIEW public.vw_smav_staff_auth_status IS 
'Readiness status of Glossy Looks staff for unified Central SMAV Salon POS login';

COMMIT;
